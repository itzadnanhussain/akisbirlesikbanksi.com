<?php 
echo"
<script>window.location.href='admin_profile';</script>
";

 ?>